CACHE_DIR = '/var/lib/jjjj'
RES_PATH = PATH..'/res'


local config = {}
return config
